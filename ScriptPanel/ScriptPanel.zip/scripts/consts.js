define(function() {

    return {
        LS: {
            Scripts: "SandwichRocks"
        },
        Sample: [{
            name: 'Hello World',
            group: 'Default',
            script: 'alert("Hello from injected script !!!")'
        }]
    };
});